<?php
    require_once("controleur/controleur.class.php");
    $unControleur = new Controleur();

?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>Projectworlds Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <body>
        <div>
            <?php
                require 'header.php';
            ?>
            <div class="container">
                <div class="jumbotron">
                    <h1>Bienvenu sur PC Asus Store!</h1>
                    <p> Nous avions un ensemble de pc haute gamme à vous offrir.</p>
                </div>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            <a href="gestion_panier.php">
                                <img src="img/pc_bureau_1.jpg" alt="PC Bureau">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>PC Bureau Asus ROG G11CD </h3>
                                    <p>Prix: 1000 EUR</p>
                                    
                                        <p><a href="#" role="button" class="btn btn-primary btn-block"> Acheter </a></p>
                                        
                                        <?php

                                
                                            if($unControleur->verifAddPanier(1)){
                                                echo '<a href="#" class=btn btn-block btn-success disabled> Ajouter au panier</a>';
                                            }else{
                                                
                                        ?>


                                            <a href="gestion_panier.php?idArticle=1" class="btn btn-block btn-primary" name="ajouter" value="ajouter" class="btn btn-block btr-primary">Ajouter au panier </a>
                                    <?php
                                        }

                                        
                                    ?>
                                    
                                    
                                </div>
                            </center>
                        </div>
                    </div>

                   
                </div>
                
            </div>

            <br><br><br><br><br><br><br><br>
           
            <footer class="footer">
               <div class="container">
                <center>
                   <p>Copyright &copy Projectworlds</a> Store. All Rights Reserved.</p>
                   <p>This website is developed by </p>
               </center>
               </div>
           </footer>

        </div>

    </body>
</html>
