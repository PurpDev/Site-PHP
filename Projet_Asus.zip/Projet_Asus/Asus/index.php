<?php
    require_once("controleur/controleur.class.php");
    //instancier la classe contoleur en créant un objet
    $unControleur = new Controleur();
?>


<!DOCTYPE html>
<html>
    <head>

        <title>Site Vente PC Asus </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->

        
        <!--<link rel = "stylesheet" type = "text/css" href = "https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">

        <script type = "text/javascript" src = "https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"> </script>

        <link rel = "stylesheet"  type = "text/css" href = "https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css">
        -->


        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <body>
        <div>
           <?php
            require 'header.php';
           ?>
           <div id="bannerImage">
               <div class="container">
                   <center>
                   <div id="bannerContent">
                       <h1>On vend.</h1>
                       <p>50% de promotion pour les inscrits.</p>
                       <a href="products.php" class="btn btn-danger"> achat ici </a>
                   </div>
                   </center>
               </div>
           </div>
           <div class="container">
               <div class="row">
                   <div class="col-xs-4">
                       <div  class="thumbnail">
                           <a href="produit.php">
                                <img src="img/pc_asus.jpg" alt="PC">
                           </a>
                           <center>
                                <div class="caption">
                                        <p id="autoResize">PC Asus</p>
                                        <p>Choississer parmi les meilleurs.</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="produit.php">
                               <img src="img/pc_gaming.jpg" alt="PC">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">PC Gaming </p>
                                    <p>Les PC Gaming les plus performant.</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="produit.php">
                               <img src="img/pc_bureau.jpg" alt="PC">
                           </a>
                           <center>
                               <div class="caption">
                                   <p id="autoResize">PC Bureau</p>
                                   <p>Les PC Bureau très efficace .</p>
                               </div>
                           </center>
                       </div>
                   </div>
               </div>
           </div>


                
        <?php
                if (isset($_GET['page']))
                {
                    $page = $_GET['page'];

                }else{
                    $page = 0;
                }
                switch($page){
                    //case 0: require_once("home.php"); break;
                    case 1: require_once("gestion_client.php"); break;
                    case 2: require_once("gestion_categorie.php"); break;
                    case 3: require_once("gestion_article.php"); break;
                    case 4: require_once("gestion_commande.php"); break;
                    case 5: require_once("gestion_user.php"); break;
                    case 6: require_once("gestion_panier.php"); break;
                    case 7: require_once("produit.php"); break;
                    case 8: require_once("deconnexion.php"); break;
                    case 9: require_once("inscription.php"); break;


                    /*case 10: session_destroy();*/
                            header("Location: index.php");
                            break;
                    //default : require_once("home.php"); 


                }
            ?>



            <br><br> <br><br><br><br>
           <footer class="footer"> 
               <div class="container">
               <center>
                   <p>Copyright &copy Store. Tout droits réservé.</p>
                   <p>Le site a été developper par  </p>
               </center>
               </div>
           </footer>
        </div>


    </body>
</html>