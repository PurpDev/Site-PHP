<?php
    require_once("controleur/controleur.class.php");
    //instancier la classe contoleur en créant un objet
    $unControleur = new Controleur();
?>



<?php

    $idArticle = $_GET['idPanier'];
    $idClient = $_GET['idPanier'];

    $numPanier = $unControleur->deletePanier($idClient, $idArticle);
    header('location: produit.php');


?>