<?php
    class Modele
    {
        private $unPDO;

        public function __construct()
        {
            try
            {
                $this->unPDO = new PDO("mysql:host=localhost;dbname=gestion_asus","root","");

            }

            catch(PDOException $exp)
            {
                echo "Impssible de se connecter";
            }
        }



        /******************** Client *************************** */

        public function selectAllClients()
        {
            $requete = "select * from Client;";

            $select = $this->unPDO->prepare($requete);
            
            $select->execute();

            $lesClients = $select->fetchAll();

            return $lesClients;
        }


        public function insertClient($tab)
        {
            $requete = "insert into Client values(null, :nomClient, :prenomClient, :adresseClient, :telClient, :emailClient );";
            $donne = array(":nomClient"=>$tab['nomClient'],
                            ":prenomClient"=>$tab['prenomClient'],
                            ":adresseClient"=>$tab['adresseClient'],
                            ":telClient"=>$tab['telClient'],
                            ":emailClient"=>$tab['emailClient']);

            $insert = $this->unPDO->prepare($requete);
            $insert->execute($donne);
            
        }

        public function deleteClient($idClient)
        {
            $requete = "delete from Client where idClient = :idClient;";
            $donne = array("idClient"=>$idClient);
            $delete = $this->unPDO->prepare($requete);
            $delete->execute($donne);
        }

        public function selectWhereClient($idClient)
        {
            $requete = "select * from Client where idClient = :idClient;";
            $donne = array("idClient"=>$idClient);

            $select = $this->unPDO->prepare($requete);
            $select->execute($donne);
            $unClient = $select->fetch();
            return $unClient;
        }

        public function updateClient($tab)
        {
            $requete = "update Client set nomClient = :nomClient, prenomClient = :prenomClient,
            adresseClient = :adresseClient, telClient = :telClient,  emailClient = :emailClient
            where idClient = :idClient;";

            $donne = array(":nomClient"=>$tab['nomClient'],
            ":prenomClient"=>$tab['prenomClient'],
            ":adresseClient"=>$tab['adresseClient'],
            ":telClient"=>$tab['telClient'],
            ":emailClient"=>$tab['emailClient'],
            ":idClient"=>$tab['idClient']);

            $update = $this->unPDO->prepare($requete);
            $update->execute($donne);

        }

        /************************************Categorie*********************************** */

        public function selectAllCategories()
        {
            $requete = "select * from Categorie;";

            $select = $this->unPDO->prepare($requete);
            
            $select->execute();

            $lesCategories = $select->fetchAll();

            return $lesCategories;
        }


        public function insertCategorie($tab)
        {
            $requete = "insert into Categorie values(null, :nomCategorie, :libelleCategorie);";
            $donne = array(":nomCategorie"=>$tab['nomCategorie'],
                            ":libelleCategorie"=>$tab['libelleCategorie']);

            $insert = $this->unPDO->prepare($requete);
            $insert->execute($donne);
            
        }

        public function deleteCategorie($idCategorie)
        {
            $requete = "delete from Categorie where idCategorie = :idCategorie;";
            $donne = array("idCategorie"=>$idCategorie);
            $delete = $this->unPDO->prepare($requete);
            $delete->execute($donne);
        }

        public function selectWhereCategorie($idCategorie)
        {
            $requete = "select * from Categorie where idCategorie = :idCategorie;";
            $donne = array("idCategorie"=>$idCategorie);

            $select = $this->unPDO->prepare($requete);
            $select->execute($donne);
            $uneCategorie = $select->fetch();
            return $uneCategorie;
        }

        public function updateCategorie($tab)
        {
            $requete = "update Categorie set nomCategorie = :nomCategorie, libelleCategorie = :libelleCategorie
            where idCategorie = :idCategorie;";

            $donne = array(":nomCategorie"=>$tab['nomCategorie'],
            ":libelleCategorie"=>$tab['libelleCategorie']);

            $update = $this->unPDO->prepare($requete);
            $update->execute($donne);

        }

        /*************************************Commande***************************************** */

        
        public function selectAllCommandes()
        {
            $requete = "select * from Commande;";

            $select = $this->unPDO->prepare($requete);
            
            $select->execute();

            $lesCommandes = $select->fetchAll();

            return $lesCommandes;
        }


        public function insertCommande($tab)
        {
            $requete = "insert into Commande values(null, :idClient, :typePayement);";
            $donne = array(":idClient"=>$tab['idClient'],
                            ":typePayement"=>$tab['typePayement']);

            $insert = $this->unPDO->prepare($requete);
            $insert->execute($donne);
            
        }

        public function deleteCommande($idCommande)
        {
            $requete = "delete from Commande where idCommande = :idCommande;";
            $donne = array("idCommande"=>$idCommande);
            $delete = $this->unPDO->prepare($requete);
            $delete->execute($donne);
        }

        public function selectWhereCommande($idCommande)
        {
            $requete = "select * from Commande where idCommande = :idCommande;";
            $donne = array("idCommande"=>$idCommande);

            $select = $this->unPDO->prepare($requete);
            $select->execute($donne);
            $uneCommande = $select->fetch();
            return $uneCommande;
        }

        public function updateCommande($tab)
        {
            $requete = "update Commande set idClient = :idClient, typePayement = :typePayement
            where idCommande = :idCommande;";

            $donne = array(":idClient"=>$tab['idClient'],
            ":typePayement"=>$tab['typePayement']);

            $update = $this->unPDO->prepare($requete);
            $update->execute($donne);

        }

        /**********************************Article************************************* */

        public function selectAllArticles()
        {
            $requete = "select * from Article;";

            $select = $this->unPDO->prepare($requete);
            
            $select->execute();

            $lesArticles = $select->fetchAll();

            return $lesArticles;
        }


        public function insertArticle($tab)
        {
            $requete = "insert into Article values(null, :idCategorie, :nomArticle, :processeur, :RAM, :capacite, :prixArticle, :libelleArticle, :quantiteStock );";
            $donne = array(":idCategorie"=>$tab['idCategorie'],
                            ":nomArticle"=>$tab['nomArticle'],
                            ":processeur"=>$tab['processeur'],
                            ":RAM"=>$tab['RAM'],
                            ":capacite"=>$tab['capacite'],
                            ":prixArticle"=>$tab['prixArticle'],
                            ":libelleArticle"=>$tab['libelleArticle'],
                            ":quantiteStock"=>$tab['quantiteStock']);

            $insert = $this->unPDO->prepare($requete);
            $insert->execute($donne);
            
        }

        public function deleteArticle($idArticle)
        {
            $requete = "delete from Article where idArticle = :idArticle;";
            $donne = array("idArticle"=>$idArticle);
            $delete = $this->unPDO->prepare($requete);
            $delete->execute($donne);
        }

        public function selectWhereArticle($idArticle)
        {
            $requete = "select * from Article where idArticle = :idArticle;";
            $donne = array("idArticle"=>$idArticle);

            $select = $this->unPDO->prepare($requete);
            $select->execute($donne);
            $unArticle = $select->fetch();
            return $unArticle;
        }

        public function updateArticle($tab)
        {
            $requete = "update Article set idCategorie = :idCategorie, nomArticle = :nomArticle,
            processeur = :processeur,  RAM = :RAM,
            capacite = :capacite, prixArticle = :prixArticle, libelleArticle = :libelleArticle,  quantiteStock = :quantiteStock
            where idArticle = :idArticle;";

            $donne = array(":idCategorie"=>$tab['idCategorie'],
            ":nomArticle"=>$tab['nomArticle'],
            ":processeur"=>$tab['processeur'],
            ":RAM"=>$tab['RAM'],
            ":capacite"=>$tab['capacite'],
            ":prixArticle"=>$tab['prixArticle'],
            ":libelleArticle"=>$tab['libelleArticle'],
            ":quantiteStock"=>$tab['quantiteStock'],
            ":idArticle"=>$tab['idArticle']);

            $update = $this->unPDO->prepare($requete);
            $update->execute($donne);

        }

        /***************************Panier*************************************** */

        public function selectAllPaniers()
        {
            $requete = "select * from Panier;";

            $select = $this->unPDO->prepare($requete);
            
            $select->execute();

            $lesPaniers = $select->fetchAll();

            return $lesPaniers;
        }

        /*
        public function insertPanier($tab)
        {
            $requete = "insert into Panier values(null, :idClient, :idArticle, :etatPanier);";
            $donne = array(":idClient"=>$tab['idClient'],
                            ":idArticle"=>$tab['idArticle'],
                            ":etatPanier"=>$tab['etatPanier']);

            $insert = $this->unPDO->prepare($requete);
            $insert->execute($donne);
            
        }*/

        /*
        public function insertPanier($idClient, $idArticle)
        {
            $requete = "insert into Panier values(null, '$idClient', '$idArticle', 'ajout-panier');";
            $ajout_panier =  $this->unPDO->prepare($requete);
            $ajout_panier->execute($requete);
            $res_ajout_panier = $ajout_panier->fetch();
            return $res_ajout_panier;
        }*/



        /*public function insertPanier($tab)
        {
            
            $idArticle = $_GET['idArticle'];
            $idClient = $_GET['idClient'];
            
            $requete = "select into Panier values(null,:idClient,:idArticle,:etatPanier) ;";
            $data = array(":$idClient"=>$tab['idClient'],
            ":$idArticle"=>$tab['idArticle'],
            ":etatPanier"=>'ajout-panier');

            $res_insert_produit = $this->unPDO->prepare($requete);
            $res_insert_produit->execute($data);*/


            /*$insert_produit = $this->unPDO->prepare($requete);

            $res_request->execute(array($idPanier));

            $insert_produit->execute(array());

            $res_insert_produit = $insert_produit->fetch();

            
            return $res_insert_produit;*/
        /*}*****************************************/


            
        
        public function insertPanier($idClient, $idArticle)
        {
            $requete = $this->unPDO->prepare("select into Panier values(null,idClient = :'$idClient' ,idArticle = :'$idArticle',etatPanier = :'ajout-panier');");
            //$requete = $this->unPDO->prepare("select into Panier values(null,:idClient = ,:idArticle,:etatPanier)");
            $requete->execute(array($idClient, $idArticle));
            $insert_requete = $requete->fetch();
            return $insert_requete;
            
        }

        /*public function deletePanier($idPanier)
        {
            $requete = "delete from Panier where idPanier = :idPanier;";
            $donne = array("idPanier"=>$idPanier);
            $delete = $this->unPDO->prepare($requete);
            $delete->execute($donne);
        }
        */

        /*public function deletePanier($idClient, $idArticle)
        {
            $requete = "delete from Panier values(null, '$idClient', '$idArticle', 'ajout-panier');";
            $sup_panier =  $this->unPDO->prepare($requete);
            $sup_panier->execute($requete);
            $res_sup_panier = $sup_panier->fetch();
            return $res_sup_panier;
            
        }*/



        public function selectWherePanier($idPanier)
        {
            $requete = "select * from Panier where idPanier = :idPanier;";
            
            $donne = array("idPanier"=>$idPanier);

            $select = $this->unPDO->prepare($requete);
            $select->execute($donne);
            $unPanier = $select->fetch();
            return $unPanier;
        }


        /*public function verifAddPanier($idArticle){
            $requete = "select * from Panier where '$idArticle' = :'$idArticle' and idClient = :idClient and etatPanier =  'ajout-panier';";

            $verif_produit = $this->unPDO->prepare($requete);
            $verif_produit->execute($requete);
            $numPanier = $verif_produit->fetch();
            if($numPanier >= 1) return 1;
            return 0;

        }*/


        public function deletePanier($idClient, $idArticle)
        {
            $delete_produit = $this->unPDO->prepare("delete from Panier where idClient = :'$idClient' and idArticle = :'$idArticle';");
            $delete_produit->execute(array($idArticle));
            $numPanier = $delete_produit->fetch();
            return $numPanier;

            //$donne = array("idArticle"=>$idArticle);


            /*$sup_panier =  $this->unPDO->prepare($requete);
            $sup_panier->execute($requete);
            $res_sup_panier = $sup_panier->fetch();
            return $res_sup_panier;*/
            
        }

        /*/public function updatePanier()
        {

        }*/

        public function verifAddPanier($idArticle){
        
            $verif_produit = $this->unPDO->prepare("select * from Panier where idArticle = :'$idArticle' and etatPanier =  'ajout-panier';");
            //$verif_produit = $this->unPDO->prepare($requete);
            $verif_produit->execute(array($idArticle));

            $numPanier = $verif_produit->fetch();
            if($numPanier >= 1) return 1;
            return 0;
        }

        /*******************************User********************************* */

        

        public function selectAllUsers()
        {
            $requete = "select * from  User;";

            $select =$this->unPDO->prepare($requete);

            $select->execute();

            $lesUsers = $select->fetchAll();

            return $lesUsers;
        }

        public function insertUser($tab)
        {
            $requete = "insert into User values(null, :nomUser, :prenomUser, :emailUser, :mdpUser, droits)";
            $donnees = array(":nomUser"=>$tab['nomUser'],
                            ":prenomUser"=>$tab['prenomUser'],
                            ":emailUser"=>$tab['emailUser'],
                            ":mdpUser"=>$tab['mdpUser'],
                            ":droits"=>$tab['droits']);
        
            $insert = $this->unPDO->prepare($requete);
            $insert->execute($donnees);

        }

        public function deleteUser($idUser)
        {
            $requete = "delete from User where idUser = :idUser;";
            $donnees = array("idUser"=>$idUser);
            $delete = $this->unPDO->prepare($requete);
            $delete->execute($donnees);
        }

        public function selectWhereUser($idUser)
        {
            $requete = "select * from User where idUser = :idUser;";
            $donnees = array("idUser"=>$idUser);

            $select = $this->unPDO->prepare($requete);
            $select->execute($donnees);
            $unUser = $select->fetch();
            return $unUser;


        }

        public function updateUser($tab)
        {
            $requete = "update User set nomUser = :nomUser, prenomUser = :prenomUser,
            emailUser = :emailUser, mdpUser = :mdpUser, droits = :droits
            where idUser = :idUser;";

            $donnees = array(":nomUser"=>$tab['nomUser'],
            ":prenomUser"=>$tab['prenomUser'],
            ":emailUser"=>$tab['emailUser'],
            ":mdpUser"=>$tab['mdpUser'],
            ":droits"=>$tab['droits'],
            ":idUser"=>$tab['idUser']);

            $update = $this->unPDO->prepare($requete);
            $update->execute($donnees);

        }




        
    }


?>