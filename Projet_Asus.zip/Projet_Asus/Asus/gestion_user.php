<?php
    require_once("controleur/controleur.class.php");
    //instancier la classe contoleur en créant un objet
    $unControleur = new Controleur();
?>


<!DOCTYPE html>

    <head>

        <title>Site Vente PC Asus </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->

        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>

    <body>
        <?php
            require 'header.php';
        ?>
        

                        
        <?php



            $leUser = null;
            if(isset($_GET['action']) && isset($_GET['idUser']))
            {
                $action = $_GET['action'];
                $idUser = $_GET['idUser'];

                switch($action)
                {
                    case "sup":
                        $unControleur->deleteUser($idUser);
                    break;

                    case "edit":
                        /**on cree d abord selectwherepromo ici puis on va dans le controlleur */
                        $leUser = $unControleur->selectWhereUser($idUser);
                    break;
                }
            }

            require_once("vue/vue_insert_user.php");
            if(isset($_POST['Valider']))
            {
                $unControleur->insertUser($_POST);
            }


            if(isset($_POST['Modifier']))
            {
                $unControleur->updateUser($_POST);
                header("Location: index.php?page=5");
            }

            $lesUsers = $unControleur->selectAllUsers();
            require_once("vue/vue_les_users.php");



        ?>
                
    </body>

</html>
