<?php
    require_once("controleur/controleur.class.php");
    //instancier la classe contoleur en créant un objet
    $unControleur = new Controleur();
?>

    

<!DOCTYPE html>

    <head>

        <title>Site Vente PC Asus </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->

        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>

    <body>
        <?php
            require 'header.php';
        ?>
        
        <h3> Gestion des Commandes </h3>

        <?php

            
        // a faire quand mettre la session
        /*if($_SESSION['droits'] == "admin")
        {*/
            

            $laCommande = null;
            if(isset($_GET['action']) && isset($_GET['idCommande']))
            {
                $action = $_GET['action'];
                $idCommande = $_GET['idCommande'];

                switch($action)
                {
                    case "sup":
                        $unControleur->deleteCommande($idCommande);
                    break;

                    case "edit":
                        $laCommande = $unControleur->updateCommande($idCommande);
                    break;
                }
            }

            require_once("vue/vue_insert_commande.php");
            if(isset($_POST['Valider']))
            {
                $unControleur->insertCommande($_POST);
            }


            if(isset($_POST['Modifier']))
            {
                $unControleur->updateCommande($_POST);
                header("Location: index.php?page=4");
            }

            //}

            $lesCommandes = $unControleur->selectAllCommandes();
            require_once("vue/vue_les_commandes.php");

        ?>

        

          
    </body>

</html>

