<?php
    require_once("controleur/controleur.class.php");
    //instancier la classe contoleur en créant un objet
    $unControleur = new Controleur();
?>




<!DOCTYPE html>

    <head>

        <title>Site Vente PC Asus </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->

        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>

    <body>
        <?php
            require 'header.php';
        ?>

        <h3> Gestion des Categories </h3>
                    
        <?php

                
            // a faire quand mettre la session
            /*if($_SESSION['droits'] == "admin")
            {*/
                

            $laCategorie = null;
            if(isset($_GET['action']) && isset($_GET['idCategorie']))
            {
                $action = $_GET['action'];
                $idCategorie = $_GET['idCategorie'];

                switch($action)
                {
                    case "sup":
                        $unControleur->deleteCategorie($idCategorie);
                    break;

                    case "edit":
                        $laCategorie = $unControleur->updateCategorie($idCategorie);
                    break;
                }
            }

            require_once("vue/vue_insert_categorie.php");
            if(isset($_POST['Valider']))
            {
                $unControleur->insertCategorie($_POST);
            }


            if(isset($_POST['Modifier']))
            {
                $unControleur->updateCategorie($_POST);
                header("Location: index.php?page=2");
            }

            //}

            $lesCategories = $unControleur->selectAllCategories();
            require_once("vue/vue_les_categories.php");

        ?>

          
    </body>

</html>


