<?php
    require_once("modele/modele.class.php");


    class Controleur
    {
        private $unModele;

        public function __construct()
        {
            $this->unModele = new Modele();
        }


        public function selectAllClients()
        {
            $lesClients = $this->unModele->selectAllClients();
            return $lesClients;
        }

        
        public function insertClient($tab)
        {
            $this->unModele->insertClient($tab);
        }

        public function deleteClient($idClient)
        {
            $this->unModele->deleteClient($idClient);
        }

        
        public function updateClient($idClient)
        {
            $this->unModele->updateClient($idClient);
        }

        
        /****************************Categorie***************************** */
        public function selectAllCategories()
        {
            $lesCategories = $this->unModele->selectAllCategories();
            return $lesCategories;
        }


        public function insertCategorie($tab)
        {
            $this->unModele->insertCategorie($tab);
        }

        public function deleteCategorie($idCategorie)
        {
            $this->unModele->deleteCategorie($idCategorie);
        }

        
        public function updateCategorie($idCategorie)
        {
            $this->unModele->updateCategorie($idCategorie);
        }

        /*******************************Commande*********************************** */


        public function selectAllCommandes()
        {
            $lesCommandes = $this->unModele->selectAllCommandes();
            return $lesCommandes;
        }


        public function insertCommande($tab)
        {
            $this->unModele->insertCommande($tab);
        }

        public function deleteCommande($idCommande)
        {
            $this->unModele->deleteCommande($idCommande);
        }

        
        public function updateCommande($idCommande)
        {
            $this->unModele->updateCommande($idCommande);
        }


        /*****************************Article****************************** */

        
        public function selectAllArticles()
        {
            $lesArticles = $this->unModele->selectAllArticles();
            return $lesArticles;
        }


        public function insertArticle($tab)
        {
            $this->unModele->insertArticle($tab);
        }

        public function deleteArticle($idArticle)
        {
            $this->unModele->deleteArticle($idArticle);
        }

        
        public function updateArticle($idArticle)
        {
            $this->unModele->updateArticle($idArticle);
        }


        /******************************Panier****************************** */


        
        public function selectAllPaniers()
        {
            $lesPaniers = $this->unModele->selectAllPaniers();
            return $lesPaniers;
        }


       /* public function insertPanier($idClient, $idArticle)
        {
            $this->unModele->insertPanier($idClient, $idArticle);
        }*/

/*
        public function insertPanier($tab)
        {
            $res_insert_produit= $this->unModele->insertPanier($tab);
            return $res_insert_produit;
        }
        */


        /*public function insertPanier($tab)
        {
            $this->unModele->insertPanier($tab);
        }*/

        
        public function insertPanier($idClient, $idArticle)
        {
            $this->unModele->insertPanier($idClient, $idArticle);
        }

        public function deletePanier($idClient, $idArticle)
        {
            $this->unModele->deletePanier($idClient, $idArticle);
        }

        
        public function verifAddPanier($idArticle)
        {
            $this->unModele->verifAddPanier($idArticle);
            return 0;
            
        }
        

        /***************************User**************************************** */


          

        public function selectAllUsers()
        {
            $lesUsers = $this->unModele->selectAllUsers();

            return $lesUsers;
        }

        public function insertUser($tab)
        {
            $this->unModele->insertUser($tab);

        }

        public function deleteUser($idUser)
        {
            $this->unModele->deleteUser($idUser);
        }

        public function selectWhereUser($idUser)
        {
            return $this->unModele->selectWhereUser($idUser);
        }

        public function updateUser($tab)
        {
            $this->unModele->updateUser($tab);
        }
   

    }


?>