
<div class = "container">
    <form method = "post" action = "">
        <div class = "form-group">
            <label> Nom Utilisateur </label>
            <input type = "text" name = "nomUser" placeholder="ecrire le nom" class = "form-control" value = "<?php
                if($leUser != null)
                {
                    echo $leUser['nomUser'];
                }
            ?>">
        </div>


        <div class = "form-group">
            <label> Prenom du Client</label>
            <input type = "text" name = "prenomUser" placeholder="ecrire le prenom" class = "form-control" value = "<?php
                if($leUser != null)
                {
                    echo $leUser['prenomUser'];
                }
            ?>">
        </div>

        
        <div class = "form-group">
            <label> Email de l'Utilisateur </label>
            <input type = "text" name = "emailUser" placeholder="donner l email" class = "form-control" value ="<?php
                if($leUser != null)
                {
                    echo $leUser['emailUser'];
                } 
            ?>">
        </div>


        <div class = "form-group">
            <label> MDP Utilisateur </label>
            <input type = "text" name = "mdpUser" placeholder="ecrire le mdp" class = "form-control" value ="<?php
                if($leUser != null)
                {
                    echo $leUser['mdpUser'];
                } 
            ?>">
        </div>

        <div class = "form-group"> 
            <label> Role Utilisateur </label>
            <input type = "text" name = "droits" placeholder="donner le type de droits" class = "form-control" value ="<?php
                if($leUser != null)
                {
                    echo $leUser['droits'];
                } 
            ?>">
        </div>

        <div class = "form-group">
            <input type = "reset" name = "Annuler" value = "Annuler">
            <input type = "submit"
                <?php
                /**pour modifier et valider  */
                if ($leUser == null )
                    echo 'name = "Valider" value = "Valider"';
                else
                    echo 'name = "Modifier" value = "Modifier"';
                ?>
            >

        </div>

        <?php
            if($leUser != null)
                echo '<input type="hidden" name = "idUser"
                    value ="'.$leUser['idUser'].'">';
        ?>

    </form>
</div>