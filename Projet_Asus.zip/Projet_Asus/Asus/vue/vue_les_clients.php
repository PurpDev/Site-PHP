<h4 class = "text-center text-danger"> Affichage des resultats </h4>

<?php
    
    echo "<table class = 'table table-bordered'>
    <tr class = 'bg-primary text-center'> <th> ID Client </th> <td> Nom Client </th> <th> Adresse Client </th>
    <th> Telephone Client </th> <th> Email Client </th> <th> Oprérations </th> <tr>";

    foreach ($lesClients as $unClient){
        echo "<tr> <td> ".$unClient["idClient"]."</td>
                    <td> ".$unClient["nomClient"]."</td>
                    <td> ".$unClient["adresseClient"]."</td>
                    <td> ".$unClient["telClient"]."</td>
                    <td> ".$unClient["emailClient"]."</td>
                    <td> 
                    <a href='index.php?page=1&action=sup&idClient=".$unClient["idClient"]."'> <img src='img/icon_delete.png' width='30' height='30'> </a> 

                    <a href='index.php?page=1&action=edit&idClient=".$unClient["idClient"]."'> <img src='img/icon_edit.png' width='30' height='30'> </a> 
                    </td>                     
                </tr>";
                
    }
    echo "</table>";

?>