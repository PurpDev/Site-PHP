<h4 class = "text-center text-danger"> Affichage des resultats </h4>

<?php
    
    echo "<table class = 'table table-bordered'>
    <tr class = 'bg-primary text-center'> <th> ID Article </th> <th> ID Categorie </th> <td> Nom Article </th> <th> Processeur </th>
    <th> RAM </th> <th> Capacite </th> <th> Prix Article </th> <th> Libelle </th> <th> Quantite en Stock </th> 
    <th> Oprérations </th> <tr>";

    foreach ($lesArticles as $unArticle){
        echo "<tr> <td> ".$unArticle["idArticle"]."</td>
                    <td> ".$unArticle["idCategorie"]."</td>
                    <td> ".$unArticle["nomArticle"]."</td>
                    <td> ".$unArticle["processeur"]."</td>
                    <td> ".$unArticle["RAM"]."</td>
                    <td> ".$unArticle["capacite"]."</td>
                    <td> ".$unArticle["prixArticle"]."</td>
                    <td> ".$unArticle["libelleArticle"]."</td>
                    <td> ".$unArticle["quantiteStock"]."</td>
                    <td> 
                    <a href='index.php?page=3&action=sup&idArticle=".$unArticle["idArticle"]."'> <img src='img/icon_delete.png' width='30' height='30'> </a> 

                    <a href='index.php?page=3&action=edit&idArticle=".$unArticle["idArticle"]."'> <img src='img/icon_edit.png' width='30' height='30'> </a> 
                    </td>                     
                </tr>";
                
    }
    echo "</table>";

?>