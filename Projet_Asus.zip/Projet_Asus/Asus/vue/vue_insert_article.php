
<div class = "container">
    <form method = "post" action = "">
       
        <div  class = "form-group">
            <label> La Categorie (ID) </label>
            <select type = "text" name = "idCategorie" class = "form-control">

                <?php
                    $lesCategories = $unControleur->selectAllCategories();
                    foreach ($lesCategories as $uneCategorie) {
                    echo "<option value='".$uneCategorie['idCategorie']."'>".$uneCategorie['nomCategorie']."</option>";
                    }
                ?>
            </select>

        </div>


        <div class = "form-group">
            <label> nom de l'Article</label>
            <input type = "text" name = "nomArticle" placeholder="ecrire le nom " class = "form-control" value = "<?php
                if($lArticle != null)
                {
                    echo $lArticle['nomArticle'];
                }
            ?>">
        </div>


        <div class = "form-group">
            <label> Processeur </label>
            <input type = "text" name = "processeur" placeholder="ecrire le type de processeur" class = "form-control" value ="<?php
                if($lArticle != null)
                {
                    echo $lArticle['processeur'];
                } 
            ?>">
        </div>

        
        <div class = "form-group">
            <label> RAM </label>
            <input type = "text" name = "RAM" placeholder="donner la taille de la RAM" class = "form-control" value ="<?php
                if($lArticle != null)
                {
                    echo $lArticle['RAM'];
                } 
            ?>">
        </div>

        
        <div class = "form-group">
            <label> La capacite </label>
            <input type = "text" name = "capacite" placeholder="donner la capacite " class = "form-control" value ="<?php
                if($lArticle != null)
                {
                    echo $lArticle['capacite'];
                } 
            ?>">
        </div>

        
        
        <div class = "form-group">
            <label> Prix </label>
            <input type = "text" name = "prixArticle" placeholder="donner le prix " class = "form-control" value ="<?php
                if($lArticle != null)
                {
                    echo $lArticle['prixArticle'];
                } 
            ?>">
        </div>

        
        <div class = "form-group">
            <label> libelle </label>
            <input type = "text" name = "libelleArticle" placeholder="ecrire le libelle" class = "form-control" value ="<?php
                if($lArticle != null)
                {
                    echo $lArticle['libelleArticle'];
                } 
            ?>">
        </div>


        
        <div class = "form-group">
            <label> Quantite en stock </label>
            <input type = "text" name = "quantiteStock" placeholder="donner la quantite en stock" class = "form-control" value ="<?php
                if($lArticle != null)
                {
                    echo $lArticle['quantiteStock'];
                } 
            ?>">
        </div>



        <div class = "form-group">
            <input type = "reset" name = "Annuler" value = "Annuler">
            <input type = "submit"
                <?php
                /**pour modifier et valider  */
                if ($lArticle == null )
                    echo 'name = "Valider" value = "Valider"';
                else
                    echo 'name = "Modifier" value = "Modifier"';
                ?>
            >

        </div>

        <?php
            if($lArticle != null)
                echo '<input type="hidden" name = "idArticle"
                    value ="'.$lArticle['idArticle'].'">';
        ?>

    </form>
</div>