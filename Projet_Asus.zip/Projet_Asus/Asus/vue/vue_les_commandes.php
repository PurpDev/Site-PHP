<h4 class = "text-center text-danger"> Affichage des resultats </h4>

<?php
    
    echo "<table class = 'table table-bordered'>
    <tr class = 'bg-primary text-center'> <th> ID Commande </th> <td> Client(ID) </th> <th> typePayement </th>
    <th> Date Commande </th> <th> Heure Commande </th> <th> Oprérations </th> <tr>";

    foreach ($lesCommandes as $uneCommande){
        echo "<tr> <td> ".$uneCommande["idCommande"]."</td>
                    <td> ".$uneCommande["idClient"]."</td>
                    <td> ".$uneCommande["typePayement"]."</td>
                    <td> ".$uneCommande["dateCommande"]."</td>
                    <td> ".$uneCommande["heureCommande"]."</td>
                    <td> 
                    <a href='index.php?page=4&action=sup&idCommande=".$uneCommande["idCommande"]."'> <img src='img/icon_delete.png' width='30' height='30'> </a> 

                    <a href='index.php?page=4&action=edit&idCommande=".$uneCommande["idCommande"]."'> <img src='img/icon_edit.png' width='30' height='30'> </a> 
                    </td>                     
                </tr>";
                
    }
    echo "</table>";

?>