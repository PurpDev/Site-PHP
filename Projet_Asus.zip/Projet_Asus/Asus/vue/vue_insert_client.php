
<div class = "container">
    <form method = "post" action = "">
        <div class = "form-group">
            <label> Nom du Client</label>
            <input type = "text" name = "nomClient" placeholder="ecrire le nom" class = "form-control" value = "<?php
                if($leClient != null)
                {
                    echo $leClient['nomClient'];
                }
            ?>">
        </div>


        <div class = "form-group">
            <label> Prenom du Client</label>
            <input type = "text" name = "prenomClient" placeholder="ecrire le prenom" class = "form-control" value = "<?php
                if($leClient != null)
                {
                    echo $leClient['prenomClient'];
                }
            ?>">
        </div>


        <div class = "form-group">
            <label> Telephone de l'Client </label>
            <input type = "text" name = "telClient" placeholder="ecrire le numero" class = "form-control" value ="<?php
                if($leClient != null)
                {
                    echo $leClient['telClient'];
                } 
            ?>">
        </div>


        <div class = "form-group">
            <label> Email de l'Client </label>
            <input type = "text" name = "emailClient" placeholder="donner l email" class = "form-control" value ="<?php
                if($leClient != null)
                {
                    echo $leClient['emailClient'];
                } 
            ?>">
        </div>

        <div class = "form-group"> 
            <label> Adresse de l'Client </label>
            <input type = "text" name = "adresseClient" placeholder="donner l'adresse" class = "form-control" value ="<?php
                if($leClient != null)
                {
                    echo $leClient['adresseClient'];
                } 
            ?>">
        </div>

        <div class = "form-group">
            <input type = "reset" name = "Annuler" value = "Annuler">
            <input type = "submit"
                <?php
                /**pour modifier et valider  */
                if ($leClient == null )
                    echo 'name = "Valider" value = "Valider"';
                else
                    echo 'name = "Modifier" value = "Modifier"';
                ?>
            >

        </div>

        <?php
            if($leClient != null)
                echo '<input type="hidden" name = "idClient"
                    value ="'.$leClient['idClient'].'">';
        ?>

    </form>
</div>