
<div class = "container">
    <form method = "post" action = "">
        <div  class = "form-group">

            <label> Le Client (ID) </label>
            <select type = "text" name = "idClient" class = "form-control">

                <?php
                    $lesClients = $unControleur->selectAllClients();
                    foreach ($lesClients as $unClient) {
                    echo "<option value='".$unClient['idClient']."'>".$unClient['nomClient']."</option>";
                    }
                ?>
            </select>

        </div>


        <div class = "form-group">
            <label> Mode Payement </label>
            <input type = "text" name = "typePayement" placeholder="ecrire le prenom" class = "form-control" value = "<?php
                if($laCommande != null)
                {
                    echo $laCommande['typePayement'];
                }
            ?>">
        </div>

        
        <div class = "form-group">
            <label> Date </label>
            <input type = "text" name = "dateCommande" placeholder="ecrire le prenom" class = "form-control" value = "<?php
                if($laCommande != null)
                {
                    echo $laCommande['dateCommande'];
                }
            ?>">
        </div>


        <div class = "form-group">
            <label> Heure  </label>
            <input type = "text" name = "heureCommande" placeholder="ecrire le prenom" class = "form-control" value = "<?php
                if($laCommande != null)
                {
                    echo $laCommande['heureCommande'];
                }
            ?>">
        </div>


        <div class = "form-group">
            <input type = "reset" name = "Annuler" value = "Annuler">
            <input type = "submit"
                <?php
                /**pour modifier et valider  */
                if ($laCommande == null )
                    echo 'name = "Valider" value = "Valider"';
                else
                    echo 'name = "Modifier" value = "Modifier"';
                ?>
            >

        </div>

        <?php
            if($laCommande != null)
                echo '<input type="hidden" name = "idCommande"
                    value ="'.$laCommande['idCommande'].'">';
        ?>

    </form>
</div>