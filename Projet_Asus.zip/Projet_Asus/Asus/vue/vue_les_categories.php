<h4 class = "text-center text-danger"> Affichage des resultats </h4>

<?php
    
    echo "<table class = 'table table-bordered'>
    <tr class = 'bg-primary text-center'> <th> ID Categorie </th> <td> Nom Categorie </th> <th> libelle Categorie </th>
    <th> Oprérations </th> <tr>";

    foreach ($lesCategories as $uneCategorie){
        echo "<tr> <td> ".$uneCategorie["idCategorie"]."</td>
                    <td> ".$uneCategorie["nomCategorie"]."</td>
                    <td> ".$uneCategorie["libelleCategorie"]."</td>
                    <td> 
                    <a href='index.php?page=2&action=sup&idCategorie=".$uneCategorie["idCategorie"]."'> <img src='img/icon_delete.png' width='30' height='30'> </a> 

                    <a href='index.php?page=2&action=edit&idCategorie=".$uneCategorie["idCategorie"]."'> <img src='img/icon_edit.png' width='30' height='30'> </a> 
                    </td>                     
                </tr>";
                
    }
    echo "</table>";

?>