
<div class = "container">
    <form method = "post" action = "">
        <div class = "form-group">
            <label> Nom Categorie</label>
            <input type = "text" name = "nomCategorie" placeholder="ecrire le nom" class = "form-control" value = "<?php
                if($laCategorie != null)
                {
                    echo $laCategorie['nomCategorie'];
                }
            ?>">
        </div>


        <div class = "form-group">
            <label> libelle </label>
            <input type = "text" name = "libelleCategorie" placeholder="ecrire le prenom" class = "form-control" value = "<?php
                if($laCategorie != null)
                {
                    echo $laCategorie['libelleCategorie'];
                }
            ?>">
        </div>

        <div class = "form-group">
            <input type = "reset" name = "Annuler" value = "Annuler">
            <input type = "submit"
                <?php
                /**pour modifier et valider  */
                if ($laCategorie == null )
                    echo 'name = "Valider" value = "Valider"';
                else
                    echo 'name = "Modifier" value = "Modifier"';
                ?>
            >

        </div>

        <?php
            if($laCategorie != null)
                echo '<input type="hidden" name = "idCategorie"
                    value ="'.$laCategorie['idCategorie'].'">';
        ?>

    </form>
</div>