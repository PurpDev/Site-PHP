DROP DATABASE IF EXISTS gestion_asus;
CREATE DATABASE gestion_asus;
USE gestion_asus;


CREATE TABLE Client(
    idClient int(4) not null auto_increment,
    nomClient varchar(30) not null,
    prenomClient varchar(30) not null,
    adresseClient varchar(30) not null,
    telClient varchar(30) not null,
    emailClient varchar(30) not null,
    PRIMARY KEY(idClient)
    
);


CREATE TABLE Categorie(
    idCategorie int(5) not null auto_increment,
    nomCategorie varchar(30),
    libelleCategorie varchar(30),
    PRIMARY KEY(idCategorie)
);



CREATE TABLE Article(
    idArticle int(4) not null auto_increment,
    idCategorie int(3) not null,
    nomArticle varchar(30) not null,
    processeur varchar(30) not null,
    RAM varchar(30) not null,
    capacite varchar(30) not null,
    prixArticle float not null,
    libelleArticle varchar(30) not null,
    quantiteStock int not null,
    PRIMARY KEY(idArticle),
    FOREIGN KEY(idCategorie) REFERENCES Categorie(idCategorie)

);

CREATE TABLE Panier(
    idPanier int(4) not null auto_increment,
    idClient int(4) not null,
    idArticle int(4) not null,
    etatPanier enum("ajout-panier", "confirmer"),
    PRIMARY KEY(idPanier),
    FOREIGN KEY(idClient) REFERENCES Client(idClient),
    FOREIGN KEY(idArticle) REFERENCES Article(idArticle)
);

/*montant float not null, dans commande*/
/*statut enum("valide", "panier"),*/

CREATE TABLE Commande(
    idCommande int(5) not null auto_increment,
    idClient int(4) not null,
    typePayement varchar(30) not null,
    dateCommande date not null,
    heureCommande time not null,
    PRIMARY KEY(idCommande),
    FOREIGN KEY(idClient) REFERENCES Client(idClient)
);

/*
CREATE TABLE Facture(
    idFacture int(5) not null auto_increment,
    idCommande int(5) not null,
    dateFacture date not null,
    heureFacture time,
    TVA enum("oui", "non"),
    PRIMARY KEY(idFacture),
    FOREIGN KEY(idCommande) REFERENCES Commande(idCommande)

);
*/



CREATE TABLE User(
    idUser int(2) not null auto_increment,
    nomUser varchar(30) not null,
    prenomUser varchar(30) not null,
    emailUser varchar(30) not null,
    mdpUser varchar(30) not null,
    droits enum("admin", "user"),
    PRIMARY KEY(idUser)

);


INSERT INTO Client VALUES(null, "LOGAN", "Bobby", "12 rue Vincennes", "0788662211", "BobbyL@gmail.com");
INSERT INTO Client VALUES(null, "BASH", "Victor", "10 rue Villpinte", "0789692910", "VictorB@gmail.com");


INSERT INTO Categorie VALUES(null, "Ordinateur ASUS", "PC bureau ");
INSERT INTO Categorie VALUES(null, "Ordinateur Gaming ASUS", "PC bureau ");
INSERT INTO Categorie VALUES(null, "PC Portable ASUS", "PC slim");
INSERT INTO Categorie VALUES(null, "Tablette ASUS Tactil ", "Tablette pour tout terrain");


INSERT INTO Article VALUES(null, "1", "PC ASUS GL10","RYZEN","8GO","512GO", "550", "Pc asus performant", "5");
INSERT INTO Article VALUES(null, "2", "PC ASUS GA35X","RYZEN","32GO","1TO", "450", "Pc asus gaming performant", "10");
INSERT INTO Article VALUES(null, "3", "PC ASUS S433","INTEL","8GO","512GO", "500", "Pc asus performant", "8");

INSERT INTO Panier VALUES(null, "1", "1", "ajout-panier");
INSERT INTO Panier VALUES(null, "2", "2", "ajout-panier");


INSERT INTO Commande VALUES(null,"1","CB Visa", "2021-05-11", "14:00:00");
INSERT INTO Commande VALUES(null,"2","CB Visa", "2021-05-12", "15:00:00");


/*
INSERT INTO Facture VALUES(null,"1", "2021-05-11", "14:00:00","oui");
INSERT INTO Facture VALUES(null,"2", "2021-05-12", "15:00:00","oui");
*/

INSERT INTO User VALUES(null,"BASH", "Lancer", "BLancer@gmail.com", "123", "admin");
INSERT INTO User VALUES(null,"YAMMATO", "Guy", "YGuy@gmail.com", "456", "user");
