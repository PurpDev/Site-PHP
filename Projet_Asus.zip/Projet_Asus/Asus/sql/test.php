

CREATE TABLE Payement(
    idPayement int(3) not null auto_increment,
    idArticle int(4) not null, 
    typePayement varchar(30),
    PRIMARY KEY(idPayement),
    FOREIGN KEY(idArticle) REFERENCES Article(idArticle)

);



INSERT INTO Payement VALUES(null, "1", "1", "CB Visa");
INSERT INTO Payement VALUES(null, "2", "2", "CB Visa");


<footer>
		<div class="wrapper footer">
			<ul>
				<li class="links">
					<ul>
						<li>OUR COMPANY</li>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Terms</a></li>
						<li><a href="#">Policy</a></li>
						<li><a href="#">Contact</a></li>
					</ul>
				</li>

				<li class="links">
					<ul>
						<li>OTHERS</li>
						<li><a href="#">...</a></li>
						<li><a href="#">...</a></li>
						<li><a href="#">...</a></li>
						<li><a href="#">...</a></li>
					</ul>
				</li>

				<li class="links">
					<ul>
						<li>OUR CAR TYPES</li>
						<li><a href="#">Mercedes</a></li>
						<li><a href="#">Range Rover</a></li>
						<li><a href="#">Landcruisers</a></li>
						<li><a href="#">Others.</a></li>
					</ul>
				</li>

					<?php include_once "includes/footer.php" ?>



<?php


	public function selectAllUsers()
	{
		$requete = "select * from User;";

		$select = $this->unPDO->prepare($requete);
		
		$select->execute();

		$lesUsers = $select->fetchAll();

		return $lesUsers;
	}


	public function insertUser($tab)
	{
		$requete = "insert into User values(null, :idUser, :idArticle, :etatUser);";
		$donne = array(":idUser"=>$tab['idUser'],
						":idArticle"=>$tab['idArticle'],
						":etatUser"=>$tab['etatUser']);

		$insert = $this->unPDO->prepare($requete);
		$insert->execute($donne);
		
	}

	public function deleteUser($idUser)
	{
		$requete = "delete from User where idUser = :idUser;";
		$donne = array("idUser"=>$idUser);
		$delete = $this->unPDO->prepare($requete);
		$delete->execute($donne);
	}

	public function selectWhereUser($idUser)
	{
		$requete = "select * from User where idUser = :idUser;";
		$donne = array("idUser"=>$idUser);

		$select = $this->unPDO->prepare($requete);
		$select->execute($donne);
		$unUser = $select->fetch();
		return $unUser;
	}

	public function updateUser($tab)
	{
		$requete = "update User set idUser = :idUser, idArticle = :idArticle,
		etatUser = :etatUser,  RAM = :RAM,
		capacite = :capacite, prixUser = :prixUser, libelleUser = :libelleUser,  quantiteStock = :quantiteStock
		where idUser = :idUser;";

		$donne = array(":idUser"=>$tab['idUser'],
		":idArticle"=>$tab['idArticle'],
		":etatUser"=>$tab['etatUser'],
		":RAM"=>$tab['RAM']);

		$update = $this->unPDO->prepare($requete);
		$update->execute($donne);

	}


	public function selectAllUsers()
	{
		$lesUsers = $this->unModele->selectAllUsers();
		return $lesUsers;
	}


	public function insertUser($tab)
	{
		$this->unModele->insertUser($tab);
	}

	public function deleteUser($idUser)
	{
		$this->unModele->deleteUser($idUser);
	}

?>