<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Document</title>
    </head>
    <body>

        <h2>QUI SOMMMES NOUS </h2>

        <h3> Paragraphe 1</h3>
        <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        </p>
        
        <br>
        <br>
        <br>

        <h3> Paragraphe 2 </h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, nam error? Voluptates placeat quas odit distinctio,
        et quam repellat ut fuga quisquam accusamus eveniet voluptate debitis, possimus iste, exercitationem soluta.
        </p>


        
    </body>
</html>