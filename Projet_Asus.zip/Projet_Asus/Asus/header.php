<nav class="navbar navbar-inverse navabar-fixed-top">
    <div class="container">
        <div class="navbar-header">

            <div class = "top-nav">
            
                <ul>
                    <li>
                        <a href="gestion_client.php?page=1"> Client </a>
                    </li>

                    <li>
                        <a href="gestion_categorie.php?page=2"> Categorie </a>
                    </li>

                    <li >
                        <a href="gestion_article.php?page=3"> Article </a>
                    </li>

                    <li>
                        <a href="gestion_commande.php?page=4"> Commande </a>
                    </li>

                    <li>
                        <a href="gestion_user.php?page=5"> User </a>
                    </li>

                    
                    <li>
                        <a href="gestion_panier.php?page=6"> Panier </a>
                    </li>

                    
                    <li>
                        <a href="produit.php?page=7"> Produit </a>
                    </li>
                    
                    <li>
                        <a href="deconnexion.php?page=8"> Deconnexion </a>
                    </li>

                    <li>
                        <a href="inscription.php?page=9"> Inscription </a>
                    </li>  
                </ul>
            </div>
            
            <a href="index.php" class="navbar-brand"> Asus </a>        

    
        </div>
        
        
    </div>

</nav>




