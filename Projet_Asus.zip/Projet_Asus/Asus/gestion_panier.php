<?php
    require_once("controleur/controleur.class.php");
    //instancier la classe contoleur en créant un objet
    $unControleur = new Controleur();
?>



<?php
    /**On utilise ?> <?php quand on a 1 php inclus dans un autre  */
    /*$requete = "select a.idArticle, a.nomArticle, a.prixArticle
                from Panier p, Article a, Client c where a.idArticle = p.idArtcle 
                and p.idClient = c.'$idClient'; ";
    */



    /*
    $requete = "select a.idArticle, a.nomArticle, a.prixArticle
                from Panier p, Article a, Client c where a.idArticle = p.idArtcle 
                and p.idClient = c.idClient;";


    $res_request = $this->unPDO->prepare($requete);
    $res_request->execute(array($idPanier));
    
    */


    //$no_res_request = $res_request->fetch();

    $idClient = $_GET['idClient'];
    
    $idArticle = $_GET['idArticle'];

    //$tab = [];

    $res_insert_produit = $unControleur->insertPanier($idClient, $idArticle);
    
    
    
    //require_once("add_panier.php");

    
    $somme = 0;
    if($res_insert_produit == 0){

    ?>
        <script>
        window.alert("No items in the cart!!");
        </script>
    <?php
    }else{
        while($res_insert_produit){
            $somme = $somme + $res_insert_produit['prixArticle'];

        }
    }
    

?>

<!DOCTYPE html>

    <head>

        <title>Site Vente PC Asus </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->

        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>

    <body>
    
        <div>
            <?php 
               require 'header.php';
            ?>


            <br>


            <div class="container">
                <table class="table table-bordered table-striped">
                    <tbody>

                        <tr>
                            <th>ID Article </th><th>Nom Article</th><th>Prix </th><th> Operartion </th>
                        </tr>
                        
                        <?php 

                        /*$user_products_result=mysqli_query($con,$user_products_query) or die(mysqli_error($con));
                        $no_of_user_products= mysqli_num_rows($user_products_result);
                        $counter=1;*/

                        /*$requete = "select a.idArticle, a.nomArticle, a.prixArticle
                        from Panier p, Article a, Client c where a.idArticle = p.idArtcle 
                        and p.idClient = c.idClient; ";
                        
                        $res_request = $unControleur->unPDO->prepare($requete);
                        $res_request->execute(array($idPanier));
                        $no_res_request = $res_request->fetch();*/

                        //$tab = [];

                        
                        $res_insert_produit = $unControleur->insertPanier($idClient, $idArticle);


                        $compteur = 1;



                       while($res_insert_produit){
                           
                         ?>
                        <tr>
                            <th><?php echo $compteur ?></th><th><?php echo $res_insert_produit['nomArticle']?></th><th><?php echo $res_insert_produit['prixArticle']?></th>
                            <th><a href='delete_panier.php?idPanier=<?php echo $res_insert_produit['idArticle'] ?>'>Retirer</a></th>
                        </tr>
                       <?php $compteur=$compteur+1;}?>
                        <tr>
                            <th></th><th>Total</th><th>Rs <?php echo $somme;?>/-</th><th><a href="reussi.php?idPanier=<?php echo $res_insert_produit['idArticle']?>" class="btn btn-primary">Confirmer </a></th>
                        </tr>



                    </tbody>
                </table>
            </div>

            <br><br><br><br><br><br><br><br><br><br>


            
            <footer class="footer">
               <div class="container">
                <center>
                   <p>Copyright &copy Asus Store. Tous droits réservés.</p>
                   <p>Site développer par Stalenes CORIOLAN et Augustin DIABIRA</p>
               </center>
               </div>
           </footer>
        </div>

          
    </body>

</html>
