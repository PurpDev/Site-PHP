<?php
    require_once("controleur/controleur.class.php");
    //instancier la classe contoleur en créant un objet
    $unControleur = new Controleur();
?>


<!DOCTYPE html>

    <head>

        <title>Site Vente PC Asus </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->

        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>

    <body>
        <?php
            require 'header.php';
        ?>

        <h3> Gestion des Articles </h3>


                
        <?php

                
            // a faire quand mettre la session
            /*if($_SESSION['droits'] == "admin")
            {*/
                            

            $lArticle = null;
            if(isset($_GET['action']) && isset($_GET['idArticle']))
            {
                $action = $_GET['action'];
                $idArticle = $_GET['idArticle'];

                switch($action)
                {
                    case "sup":
                        $unControleur->deleteArticle($idArticle);
                    break;

                    case "edit":
                        $lArticle = $unControleur->updateArticle($idArticle);
                    break;
                }
            }

            require_once("vue/vue_insert_article.php");
            if(isset($_POST['Valider']))
            {
                $unControleur->insertArticle($_POST);
            }


            if(isset($_POST['Modifier']))
            {
                $unControleur->updateArticle($_POST);
                header("Location: index.php?page=3");
            }

            //}

            $lesArticles = $unControleur->selectAllArticles();
            require_once("vue/vue_les_articles.php");

        ?>
          
    </body>

</html>

