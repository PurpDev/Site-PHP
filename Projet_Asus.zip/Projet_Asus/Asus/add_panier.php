
<?php

    $idArticle = $_GET['idArticle'];
    $idClient = $_GET['idClient'];
    //$tab = [];    

    //$unAjoutPanier = $unControleur->insertPanier($idClient, $idArticle);

    //$no_insert_produit = $unControleur->insertPanier($idClient, $idArticle);

    //$res_insert_produit = $unControleur->insertPanier($tab);


    header('location: produit.php');


?>